---
sidebar_position: 4
---

# ChainNet's Expanded Chain Support

## Introduction

As ChainNet continues to evolve and expand its decentralized hosting capabilities, we are excited to announce support for additional blockchain networks, including **Ethereum**, **Binance Smart Chain (BSC)**, **Base**, and the **Sepolia testnet**. This update not only broadens the accessibility of our on-chain website hosting but also enhances the versatility of our platform by allowing developers to experiment, test, and deploy on different chains.

In this guide, we will explore how to leverage the expanded chain support, the advantages of each chain, how to utilize the Sepolia testnet for testing purposes, and provide helpful links to resources for each chain.

## Supported Chains Overview

ChainNet’s core offering of fully decentralized, on-chain website hosting is now accessible on **four major chains**:

### 1. Ethereum Mainnet

Ethereum is the world's leading smart contract platform, widely recognized for its security and large developer community. Hosting on Ethereum ensures that your content is secure and benefits from the highest level of decentralization.

- **Mainnet**: [Etherscan Explorer](https://etherscan.io/)
- **RPC Endpoint**: `https://mainnet.infura.io/v3/YOUR_INFURA_PROJECT_ID`

### 2. Binance Smart Chain (BSC)

A fast and low-cost blockchain that supports smart contracts and is fully EVM-compatible. BSC is widely used in the DeFi space and offers an attractive option for developers seeking lower transaction fees.

- **Mainnet**: [Binance Smart Chain Explorer](https://bscscan.com/)
- **RPC Endpoint**: `https://bsc-dataseed.binance.org/`

### 3. Base

A layer-2 scaling solution for Ethereum that aims to offer low fees and fast transaction times while maintaining security through Ethereum's robust network. Base is gaining traction for decentralized applications, making it an excellent choice for web3 developers.

- **Mainnet**: [BaseScan Explorer](https://basescan.org/)
- **RPC Endpoint**: `https://mainnet.base.org/`

### 4. Sepolia Testnet

A test network where developers can experiment with new features and deploy contracts without spending real funds. Sepolia is ideal for developers who want to test their on-chain websites before launching them on the Ethereum mainnet or other chains.

- **Testnet**: [Sepolia Explorer](https://sepolia.etherscan.io/)
- **Faucet**: [Sepolia Faucet](https://faucet.sepolia.dev/)

## Advantages of Using Multiple Chains

By supporting multiple blockchain networks, ChainNet empowers developers and businesses to choose the most suitable network based on their specific needs. Here’s why this is significant:

### 1. **Cost Efficiency**

- **BSC** offers significantly lower gas fees compared to Ethereum. This makes it an excellent choice for deploying on-chain websites that require frequent updates or for developers who want to reduce operational costs without sacrificing the security and decentralization offered by EVM-compatible chains.

- **Sepolia Testnet** allows developers to test their deployments without worrying about gas costs at all, making it a great resource for experimentation.

### 2. **Speed and Scalability**

- **Base** is designed to provide faster transaction times and lower fees while leveraging Ethereum's security. As a Layer 2 solution, it provides high throughput for decentralized web hosting, allowing faster load times and improved user experience for on-chain websites.

### 3. **Interoperability**

With support for multiple chains, ChainNet ensures that your content is accessible to a wide range of users. Whether they interact with Ethereum, BSC, or Base, ChainNet’s decentralized hosting can reach a broader audience across different blockchain ecosystems.

### 4. **Testing with Sepolia Testnet**

**Sepolia Testnet** is a game-changer for developers. Before deploying a live on-chain website, you can test the functionality, UI, and performance on Sepolia, ensuring that everything works as intended without incurring costs. By using Sepolia, you can debug and optimize your website before going live on the mainnet.

## How to Deploy on Each Chain

ChainNet’s smart contract functions remain the same across all supported chains, ensuring a consistent experience no matter which network you choose. Below is a quick guide to deploying on each chain.

### 1. Deploying on Ethereum Mainnet

To deploy your smart contract on Ethereum, use ChainNet’s smart contract functions to store and retrieve HTML, CSS, and JavaScript for your on-chain website.

- Ethereum-specific network settings:
  ```solidity
  "network": {
     "name": "Ethereum Mainnet",
     "chainId": 1
  }

Use Etherscan to track and verify your contract once deployed.

2. Deploying on Binance Smart Chain (BSC)
Deploying on BSC follows the same process as Ethereum. The only difference is the use of BSC's RPC endpoint and network ID.

Use the same setWebPageHTML, setWebPageCSS, setWebPageJS, and setWebPageURL functions to host your on-chain websites.
Ensure you are connected to BSC by setting your network to:
```
"network": {
   "name": "Binance Smart Chain",
   "chainId": 56
}
```
Use BSCScan to track and verify your contract once deployed.
3. Deploying on Base
Base provides similar EVM-compatible functionality but with layer-2 benefits. To deploy your smart contract, connect to the Base RPC endpoint, and follow the familiar process.

Base-specific network settings:
```
"network": {
   "name": "Base Mainnet",
   "chainId": 8453
}
```
Ensure your content is easily accessible to Base users by using ChainNet's on-chain functions.
4. Testing on Sepolia Testnet
For developers looking to test their contracts without spending gas fees, Sepolia is the perfect testbed.

Use the Sepolia RPC endpoint and faucet to get free test ETH.
Deploy your contracts and test your setWebPageHTML, setWebPageCSS, setWebPageJS, and setWebPageURL functions to ensure they work seamlessly before moving to a mainnet deployment.
Example Code for Cross-Chain Deployment

```
function deployOnChain(string memory _html, string memory _css, string memory _js, string memory _url) public {
    setWebPageHTML(_html);
    setWebPageCSS(_css);
    setWebPageJS(_js);
    setWebPageURL(_url);
}
```

This example can be deployed on any of the supported chains. By using ChainNet, the contract’s content is rendered directly through our browser, regardless of which chain the content resides on.

Testing and Debugging on Sepolia
We encourage developers to take advantage of Sepolia Testnet to fine-tune their deployments. By using the Sepolia Testnet:

You can perform multiple iterations of testing and refining your on-chain website.
You can simulate traffic and other stress tests without incurring fees.
Ensure the full integration of HTML, CSS, and JavaScript is functioning as expected.
With Sepolia, you can deploy, experiment, and debug confidently before going live on Ethereum, BSC, or Base.

Next Steps: What This Means for You
Whether you are a developer, business, or web3 enthusiast, ChainNet's support for multiple chains offers you more flexibility, cost savings, and enhanced performance. By adding support for Ethereum, BSC, Base, and Sepolia Testnet, we are pushing the boundaries of what is possible with decentralized web hosting.

Deploy your websites, experiment on testnets, and choose the chain that best meets your needs—all with ChainNet’s powerful and flexible platform. By leveraging different blockchains, you can create content that is truly decentralized, cost-effective, and scalable.
