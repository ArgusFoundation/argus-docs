---
sidebar_position: 1
---

# The Benefits of Using web:// Protocol

## Revolutionize Your Token with On-chain Web Hosting

As a developer, you understand the importance of transparency and security for your project. With ChainNet, you can take your token to the next level by hosting your project's website directly on the blockchain, right within the same smart contract that governs your token.

### Why Host Your Website On-chain?

- **Immutable and Censorship-resistant**: Traditional web hosting is vulnerable to takedowns, censorship, and server downtime. By hosting your website on-chain, you ensure that your content remains permanently accessible and immune to external interference. Once it's on-chain, no one can alter or remove it.

- **Unified Contract and Website**: Keep everything in one place. Your token contract can now include your project's informational website, allowing users to interact with both seamlessly through the ChainNet browser. This unification not only simplifies the user experience but also reinforces the integrity and trustworthiness of your project.

- **Decentralized and Secure**: When your website is hosted on-chain, it's not stored on any single server but across a decentralized network. This ensures that your website is always available and secure from attacks, providing peace of mind for you and your users.

### How Does It Work?

With ChainNet, hosting your website on-chain is straightforward. Simply include the HTML, CSS, and JavaScript code of your website within your smart contract using the designated functions:

- **setWebPageHTML**: Store the HTML content of your webpage.
- **setWebPageCSS**: Add the CSS for styling.
- **setWebPageJS**: Include any JavaScript for functionality.
- **setWebPageURL**: If you prefer to host your site elsewhere, simply link to it within the contract.

Once deployed, users can access your on-chain website directly via the `web://` protocol, ensuring they always interact with the content exactly as you intended.

### Benefits for Your Project

- **Enhanced Trust**: Users will appreciate the transparency of knowing your project's website is on-chain, adding an extra layer of trust.
- **No Downtime**: Your website is always up, with no reliance on third-party hosting services.
- **Cost-effective**: Save on traditional hosting fees by utilizing the blockchain to host your content.

> **ℹ️** Ready to get started? Check out our [documentation](link-to-docs) for a detailed guide on deploying and managing on-chain websites with ChainNet.

---

With ChainNet, you're not just building a token; you're building a future-proof, decentralized platform that can't be censored or shut down. Empower your project with the full potential of blockchain technology and show your users that you're committed to transparency and innovation.
