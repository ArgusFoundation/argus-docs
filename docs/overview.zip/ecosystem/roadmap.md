---
sidebar_position: 2
---

# ChainNet Roadmap

The ChainNet roadmap outlines our strategic milestones and key development phases as we strive to revolutionize web3 browsing. Each phase builds on the previous one, ensuring that ChainNet evolves into a comprehensive, secure, and user-friendly platform.

### Updated: 9/30/2024

## ChainNet Roadmap: Revolutionizing Web3 Browsing in 4 Phases

Each phase of ChainNet's roadmap is designed to progressively build a robust, user-friendly platform that will transform the web3 browsing and on-chain website hosting experience. As we move through each phase, we are committed to delivering innovative features, security enhancements, and community-driven incentives.

---

### Phase 1: Initial Foundation (Completed)

This phase focused on building the foundational elements of ChainNet and demonstrating our core technology. It set the groundwork for all future developments.

Milestones Completed:
- Launch of ChainNet Core Browser: 
   - The ChainNet browser went live, capable of interacting with smart contracts and opening web pages embedded within them.
   - Basic support for on-chain content hosting using smart contracts.
   - Integration of decentralized search powered by Bittensor AI and ZKML, allowing users to search centralized websites tied to the smart contract in the browser.

- Alpha Version Release: 
   - Rolled out the on-chain content rendering engine, allowing early adopters to interact with smart contract-based content.
   - Early access to AI-powered content discovery via Bittensor AI.
   - Feedback from early adopters gathered to inform future enhancements.

---

### Phase 2: Enhanced User Experience (Currently Ongoing)

We are now in the middle of Phase 2, focusing on improving the user interface and expanding browser functionality to make ChainNet more accessible to a broader audience.

Milestones Completed:
- ChainNet 2.0 Launch:
   - New intuitive and user-friendly interface designed for a smoother browsing experience.
   - Introduction of browser extensions that provide direct access to key information linked to smart contracts.
   - Enhanced infrastructure for improved performance and faster browsing.

Upcoming in Phase 2:
- Chrome Extension Integration:
   - ChainNet will soon be available as a Chrome extension, allowing users to access on-chain browsing within their familiar browser.
   - The extension will also include a new feature to display charts and data tied to smart contracts.

- Improved Developer Tools:
   - The initial release of developer-focused tools for on-chain content management.
   - Enhanced blockchain support with integration across multiple networks.

---

### Phase 3: On-Chain Website Hosting & Ecosystem Expansion

This phase focuses on expanding ChainNet’s capabilities as a gateway to on-chain website hosting, making it easier for users to build, manage, and monetize on-chain websites.

Planned Milestones:
- On-Chain Website Builder:
   - A fully integrated builder for users to create, manage, and launch websites directly on the blockchain.
   - Early access to the beta version of the builder tool, allowing basic on-chain website creation.

- Advanced Website Tools:
   - Comprehensive tools for more complex website development (e-commerce, decentralized apps, etc.).
   - Multi-language support and collaboration features to enable teamwork on on-chain projects.

- ChainNet Marketplace:
   - Launch of the ChainNet Marketplace, a hub for discovering and purchasing on-chain services, dApps, and other digital products.
   - Integration of premium features for $CNET holders, providing exclusive tools and content.

---

### Phase 4: Community Governance and Incentives

In the final phase, we will empower the ChainNet community with governance tools and incentives to drive the project’s future development and growth.

Planned Milestones:
- Airdrops & Staking:
   - Continued airdrop programs for early adopters and contributors.
   - Introduction of staking mechanisms for $CNET holders, allowing users to earn rewards and fees from ChainNet transactions.

- Governance and Revenue Sharing:
- $CNET token holders will have the ability to participate in platform governance, voting on future updates, features, and strategic direction.
   - Revenue share programs, enabling users to capture a portion of the revenue generated from the on-chain hosting services, marketplace, and dApps.

- Long-Term Incentive Programs:
   - Expansion of the governance model and reward programs to incentivize user engagement and development contributions.
   - Long-term focus on building a sustainable, community-driven ecosystem.

---

### Conclusion

With the completion of Phase 1 and our current progress in Phase 2, ChainNet is poised to lead the future of web3 browsing and on-chain website hosting. As we transition into Phase 3 and Phase 4, we remain committed to delivering innovative tools and community-driven features that will shape the next era of decentralized web infrastructure.

Join us on this journey and stay tuned for the exciting developments to come as we revolutionize web hosting forever.