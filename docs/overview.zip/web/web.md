---
sidebar_position: 1
---

# Introduction to the `web://` Protocol

The `web://` protocol is one of the most revolutionary features introduced by ChainNet. This protocol redefines how users interact with the decentralized web by allowing direct access to smart contracts through the browser’s address bar. Here’s how it works:

## How `web://` Works

When you enter a smart contract address into the ChainNet browser using the `web://` protocol, the browser automatically checks if the contract contains specific functions that are compatible with ChainNet. These default functions include:

- **getWebPageHTML**: Retrieves the HTML content of the page.
- **getWebPageCSS**: Fetches the CSS styles for the page.
- **getWebPageJS**: Provides any JavaScript associated with the page.
- **getWebPageURL**: Checks for a URL pointing to an off-chain hosted page.

### What Happens Next?

- **If Functions Are Present**: If the contract includes these functions, ChainNet seamlessly renders the webpage directly from the blockchain, providing a fully decentralized browsing experience. This ensures that the content is immutable, censorship-resistant, and hosted entirely on-chain.

- **If Functions Are Absent**: If the contract does not contain these functions, ChainNet doesn't stop there. The browser leverages Bittensor AI, an advanced AI tool built on the TAO network, to search the web for any associated websites or content. This AI-driven assistant scours the internet to find relevant information, ensuring that you still have access to the resources you need, even if they’re not directly embedded in the contract.

## Why Use `web://`?

The `web://` protocol simplifies the way users interact with decentralized applications and smart contracts. Instead of manually navigating through complex blockchain interfaces, users can now directly access on-chain content through a simple, familiar browser interface. Here are some of the key benefits:

- **Ease of Use**: Just like entering a URL in traditional browsers, you can now access smart contracts by simply typing `web://contract_address`.
- **Censorship Resistance**: Since the content is hosted on-chain, it’s immune to censorship, ensuring that you have unfettered access to the information.
- **AI-Powered Discovery**: With Bittensor AI, even if the content isn’t directly available on-chain, you’ll still be guided to the relevant resources, thanks to the decentralized intelligence of TAO.

> **ℹ️ Note:** The `web://` protocol is designed to work seamlessly with smart contracts that follow ChainNet's standard for on-chain content hosting. Developers are encouraged to implement the necessary functions in their contracts to ensure full compatibility with ChainNet.

## 🛠️ Developer Tips

For developers looking to make their smart contracts compatible with the `web://` protocol, here’s a quick guide:

- **Implement Default Functions**: Ensure that your contract includes the `getWebPageHTML`, `getWebPageCSS`, `getWebPageJS`, and `getWebPageURL` functions.
- **Test with ChainNet**: Use the ChainNet browser to test your contract and ensure that it renders correctly using the `web://` protocol.
- **Leverage TAO AI**: Consider integrating your off-chain resources in a way that Bittensor AI can easily associate them with your smart contract.

## 📚 Learn More

For more detailed information on how to implement these functions and fully utilize the `web://` protocol, visit our [Developer Documentation](./docs/).

---

The `web://` protocol is a game-changer for the decentralized web, providing a bridge between on-chain and off-chain content, and making web3 more accessible and user-friendly than ever before.
