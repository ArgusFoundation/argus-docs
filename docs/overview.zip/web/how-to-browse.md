# How to Browse Contracts Directly

Ready to see how easy it is to browse contracts directly using ChainNet? We've prepared a quick video guide that walks you through the entire process.

🎥 **Watch our Quick Video Tutorial**

Our video will show you:
- How to use the `web://` protocol to access smart contracts.
- What happens when you enter a contract address in the ChainNet browser.
- How ChainNet renders on-chain content or finds associated web resources using Bittensor AI.

> **ℹ️** Don't worry if you're new to this – our step-by-step guide will have you browsing contracts like a pro in no time!

<video controls width="100%">
  <source src="https://i.imgur.com/K7jvqfi.mp4"/>
</video>    

---

With ChainNet, browsing smart contracts is as easy as browsing the traditional web. No more complex interfaces or confusing blockchain jargon – just simple, intuitive browsing.
