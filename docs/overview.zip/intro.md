---
sidebar_position: 1
---

# Introduction

<video controls width="100%">
  <source src="https://i.imgur.com/0zBuDjL.mp4"/>
</video>


ChainNet is a **cutting-edge web3 browser** that revolutionizes how users interact with the decentralized web. By leveraging innovative technologies like the `web://` protocol and integrating AI-powered search, ChainNet is designed to unlock the full potential of web3 and redefine the browsing experience.

## Key Features

### 1. **Decentralized Web Hosting**

With ChainNet, you can **host your informational websites directly on-chain**. This innovative approach eliminates the need for third-party hosting services, making your content **censorship-resistant** and **fully decentralized**. HTML, CSS, and JavaScript can be embedded within smart contracts, allowing the browser to render complete web pages directly from the blockchain.

### 2. **The `web://` Protocol**

ChainNet introduces the `web://` protocol, a **groundbreaking feature** that allows users to browse smart contracts as if they were traditional web addresses. By simply entering a contract address using `web://`, users can instantly access the associated on-chain content, including hosted websites and more.

### 3. **AI-Powered Search with Bittensor**

In partnership with Bittensor AI, ChainNet features an **advanced AI search engine** that can scour the web for off-chain content linked to smart contracts. Whether the content is stored on-chain or elsewhere, ChainNet’s AI capabilities ensure that you can always find what you need.

### 4. **Privacy-Focused Browsing**

ChainNet is designed with **privacy at its core**. Users enjoy a secure, **ad-free browsing experience** without the need for KYC or invasive tracking. Your data is yours, and with ChainNet, you can browse the decentralized web without compromising your privacy.

## Why ChainNet?

ChainNet isn't just another browser—it's a **gateway to the future of the internet**. By merging the principles of decentralization with powerful, user-friendly features, ChainNet empowers users and developers alike to fully embrace the possibilities of web3.

- **Developers**: Easily deploy and render web content directly from smart contracts, creating truly decentralized applications.
- **Users**: Experience the decentralized web in a way that’s intuitive, secure, and censorship-resistant.
- **Crypto Enthusiasts**: Access and explore the full potential of blockchain technology through a browser built specifically for the web3 ecosystem.

## Learn More

To get started with ChainNet, explore the following sections:

- [How to Download and Install ChainNet](./getting/download)
- [Using the `web://` Protocol](./web)
- [Deploying and Managing On-Chain Content](./deploy/how-to-use)
- [ChainNet Tokenomics and Ecosystem](./ecosystem/holdings)
- [FAQ](./ecosystem/faq)
- [Roadmap](./ecosystem/roadmap)

## Conclusion

ChainNet represents the **next evolution of web browsing**—one that’s decentralized, private, and built for the future of the internet. Whether you’re a developer looking to build on the blockchain or a user seeking a secure and innovative browsing experience, ChainNet offers the tools and features you need to thrive in the web3 world.

---